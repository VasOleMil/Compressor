@bin\CompMS.exe
@CMD /K