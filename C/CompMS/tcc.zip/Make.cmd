@PowerShell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '.\Make.ps1'"
@CMD /K