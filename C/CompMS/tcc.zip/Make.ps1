# Settings
$srcFiles = @(
    "ver\test.c", 
    "ver\CompTest.c", 
    "ver\ListTest.c",
    "src\CBase.c",
    "src\CData.c",
    "src\CList.c",
    "src\CSort.c",
    "src\CEmnt.c",
    "src\CHold.c",
    "src\CMode.c",
    "src\CComp.c")   # source .c files
$objDir   = "obj"
$binDir   = "bin"
$outExe   = Join-Path $binDir "CompMS.exe"

# Directory create
New-Item -ItemType Directory -Force -Path $objDir | Out-Null
New-Item -ItemType Directory -Force -Path $binDir | Out-Null

# Obj files array
$objFiles = @()

foreach ($src in $srcFiles) {
    $obj = Join-Path $objDir ([System.IO.Path]::GetFileNameWithoutExtension($src) + ".obj")
    $objFiles += $obj

    $srcTime = (Get-Item $src).LastWriteTime
    $objTime = if (Test-Path $obj) { (Get-Item $obj).LastWriteTime } else { Get-Date "1900-01-01" }
    # compile only src changed after obj creation
    if ($objTime -lt $srcTime) {
        Write-Host "Compiling $src -> $obj"
        tcc.exe -c $src -o $obj
    } else {
        Write-Host "$obj is up to date."
    }
}
# Create executable
Write-Host "Linking -> $outExe"
tcc.exe $objFiles -o $outExe
Write-Host "Build complete."
